<?xml version="1.0" encoding="UTF-8"?>
<tileset name="walls" tilewidth="16" tileheight="16" tilecount="12" columns="12">
 <image source="walls.png" width="192" height="16"/>
</tileset>
